NHL 2000 Ditty Importer Read Me
-------------------------------
There are 2 versions of the Ditty Importer.
WIMPDITT.EXE is the Windows based Ditty Importer.
IMPDITT.EXE is the command line based Ditty Importer, which can accept wildcards and is intended for advanced users.

The Ditty Importer is a utility that will allow you to convert MP3's, WAV's, and AIF's for use with NHL 2000.  A ditty is the music played during stoppages in play and during the intermissions.

Both versions of the Ditty Importer will automatically place the converted file in the appropriate folder in the NHL 2000 installation directory.  You can have as many imported ditties as you want.  The game will randomly choose an imported ditty to play during a play stoppage.

Important Note -- if you have 64 MB RAM or less, we recommend that you have at least 100 MB of hard disk space free on your C: drive during the conversion process.
-------------------------------
Windows Ditty Importer

1. Double Click the WIMPDITT.EXE executable.
2. Choose a file (MP3, WAV, or AIF) to convert by clicking on the Browse button.
3. The Output folder is automatically pointed to the appropriate game folder.
4. You can choose to preview the ditty by clicking the Preview Button.
5. You can adjust the amount of reverb on the ditty by adjusting the Reverb Slider.
6. Checking the Crop Option will only convert approximately the first 90 seconds of the ditty.
7. Once you've adjusted all your options, press the Import button to start the conversion process.
8. Once the progress bar is full, you now have an imported ditty.

-------------------------------
Command Line Ditty Importer

1. Open up a DOS prompt.
2. Type IMPDITT followed by the name of the files you want to import.  E.G. IMPDITT test.mp3
3. You can also use wildcards for the filenames.  E.G. IMPDITT test*.mp3
4. There are also 2 options you can use here: 
   -c to crop the ditty so only the first 90 seconds of the song is converted.
   -r # (where # is a number from 0 to 127) to set the reverb level - 0 meaning no reverb
   E.G. IMPDITT -c -r 50 test.mp3
   This will import test.mp3, cropping it, and setting the reverb to 50.
5. Once the progress bars have gone to full, your ditty has been imported.

Summary:

Usage:  impditt [-c] [-r reverb] files to import 
where:

-c               crop the ditty to about 1.5 minutes
-r reverb        set the reverb level (0-127) (default: 0)
files to import  audio file to import (wildcards OK)
-------------------------------

FAQ

*My ditties are not playing in the game.  What could be wrong?

There are two possible problems:
1.	Ensure that the ASF files are in the User\Ditties directory of your NHL 2000 installation.
2.	Ensure that the files all have the extension .asf.

*How do I import ditties that I have on a music CD?

You will need to convert the CD tracks to either MP3 or WAV format.  There are many freeware and shareware tools on the Internet for doing this.  Search for "CD Ripper", "CD to WAV converter", "CD to MPG converter" at any search engine.

*Why don't the regular ditties that shipped with NHL 2000 play after I've imported a few of my own?
How do I get the regular ditties to play again?

If NHL 2000 finds any user imported ditties they completely override the ones that shipped on the game CD.  To go back to regular ditties, you can either move or delete all ASF files in the User\Ditties directory.

*My ditty sounds like it is all bass in the game, but not when I play it normally.  What's wrong?

If you import a song with a lot of heavy beats the reverb begins to add up and wash out the rest of the signal.  For such songs, use a lower reverb setting.  A setting of less than 45 is recommended in such situations.

*How many ditties can I import?

As much as you have hard disk space for.

*I imported a ditty and when it played in the game (or, when I previewed it), it didn't sound right at all.  What's wrong?
The ditty importer crashes on some MP3s.  How do I get around this?

Because of the wide variety in MPEG encoders, and because not all MPEG encoders follow a consistent standard, the importer may have problems with some MPGs and may even crash.  If this happens, use an MP3 to WAV converter, and then import the WAV.  There are many freeware and shareware MPEG to WAV converters on the Internet.  Try searching for "MPG decoder", "MP3 decoder", "MPG to WAV converter", or "MP3 to WAV converter".
